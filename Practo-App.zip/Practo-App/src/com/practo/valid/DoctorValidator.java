package com.practo.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Service
public class DoctorValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(Patient.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "doctorEmail","unmKey", "Doctor Email required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "doctorPassword", "passKey","Password required");
		
		Doctor doctor = (Doctor)target;
		if(doctor.getDoctorPassword()!=null) {
			if(doctor.getDoctorPassword().length()<=3) { 
				errors.rejectValue("doctorPassword", "passKey", "password should contain more than 3 chars");
			}
		}
	}

}
