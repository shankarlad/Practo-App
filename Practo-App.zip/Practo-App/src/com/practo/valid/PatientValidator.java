package com.practo.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.practo.dto.Patient;

@Service
public class PatientValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(Patient.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "patientEmail","unmKey", "Patient Email required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "patientPassword", "passKey","Password required");
		
		Patient patient = (Patient)target;
		if(patient.getPatientPassword()!=null) {
			if(patient.getPatientPassword().length()<=3) { 
				errors.rejectValue("patientPassword", "passKey", "password should contain more than 3 chars");
			}
		}
	}

}
