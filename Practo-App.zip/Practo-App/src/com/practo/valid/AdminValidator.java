package com.practo.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.practo.dto.Admin;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Service
public class AdminValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(Patient.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminEmail","unmKey", "Admin Email required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminPassword", "passKey","Password required");
		
		Admin admin = (Admin)target;
		if(admin.getAdminPassword()!=null) {
			if(admin.getAdminPassword().length()<=3) { 
				errors.rejectValue("adminPassword", "passKey", "password should contain more than 3 chars");
			}
		}
	}

}
