package com.practo.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practo.dto.Admin;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;
import com.practo.service.AdminService;
import com.practo.service.DoctorService;
import com.practo.service.PatientService;
import com.practo.valid.AdminValidator;
import com.practo.valid.PatientValidator;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	@Autowired
	private AdminValidator adminValidator;
	
	@RequestMapping(value = "/prep_reg_forma.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("admin", new Admin());
		return "reg_forma";
	}
	
	@RequestMapping(value = "/rega.htm",method = RequestMethod.POST)
	public String regForm(Admin admin,ModelMap map) {
		adminService.addAdmin(admin);
		return "log_forma";
	}
	
	@RequestMapping(value = "/prep_log_forma.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "log_forma";
	}
	
	@RequestMapping(value = "/logina.htm",method = RequestMethod.POST)
	public String login(Admin admin,BindingResult result,ModelMap map,HttpSession session) {
		
		adminValidator.validate(admin,result);
		if(result.hasErrors()) {
			return "log_forma";
		}
		
		boolean b = adminService.findAdmin(admin);
		if(b) {
			session.setAttribute("admin", admin);
			return "homea";
		}else {
			map.put("admin", new Admin());	
			return "log_forma";
		}
	}

}