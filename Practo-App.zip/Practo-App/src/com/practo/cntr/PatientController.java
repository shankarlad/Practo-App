package com.practo.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practo.dto.Doctor;
import com.practo.dto.Patient;
import com.practo.service.PatientService;
import com.practo.valid.PatientValidator;

@Controller
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	@Autowired
	private PatientValidator patientValidator;
	@Autowired
	private MailSender mailSender;

	/**/
	@RequestMapping(value = "/prep_reg_formp.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("patient", new Patient());
		return "reg_formp";
	}
	
	@RequestMapping(value = "/regp.htm",method = RequestMethod.POST)
	public String regForm(Patient patient,ModelMap map) {
		patientService.addPatient(patient);
		return "log_formp";
	}
	
	@RequestMapping(value = "/prep_log_formp.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("patient", new Patient());
		return "log_formp";
	}
	
	@RequestMapping(value = "/loginp.htm",method = RequestMethod.POST)
	public String login(Patient patient,BindingResult result,ModelMap map,HttpSession session) {

		
		patientValidator.validate(patient,result);
		if(result.hasErrors()) {
			return "log_formp";
		}
		
		
		
		boolean b = patientService.findUser(patient);
		if(b) {
			session.setAttribute("patient", patient);
			return "homep";
		}else {
			map.put("patient", new Patient());	
			return "log_formp";
		}
	}
	
	
	@RequestMapping(value = "/prep_profile_formp.htm",method = RequestMethod.GET)
	public String prepProfileForm(ModelMap map) {
		map.put("patient", new Patient());
		return "profile_formp";
	}
	
	@RequestMapping(value = "/prep_update_formp.htm",method = RequestMethod.GET)
	public String patientUpdateForm(@RequestParam int patientId,ModelMap map) {
		
		Patient pat = patientService.findPatient(patientId);
		map.put("patient", pat);
		
		return "update_formp";
	}

	@RequestMapping(value = "/profile_update_formp.htm",method = RequestMethod.POST)
	public String patientUpdate(Patient patient,ModelMap map,HttpSession session) {
		
		int patientId = ((Patient)session.getAttribute("patient")).getPatientId();
		patient.setPatientId(patientId);
		
		patientService.modifyPatient(patient);
		return "log_formp";
	}
	
	@RequestMapping(value = "/prep_patient_lista.htm",method = RequestMethod.GET)
	public String searchAPatient(Patient patient,ModelMap map,HttpSession session) {
	
		List<Patient> li = patientService.findAllPatientList(patient);
		map.put("dList", li);
		return "patient_lista"; 
	
	}
	
	@RequestMapping(value = "logout_here.htm")
	public String LogoutHere(HttpSession session) {
		session.removeAttribute("patient");
		session.invalidate();
		
		return "index";
	}

	@RequestMapping(value = "/forgot_passwordp.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String patientEmail,ModelMap map) {		
		String pass = patientService.forgotPassword(patientEmail);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("cdacmumbai3@gmail.com");  
	        message.setTo(patientEmail);  
	        message.setSubject("Your password");  
	        message.setText(pass);    
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "index";
	}

	
}
