package com.practo.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practo.dto.Doctor;
import com.practo.dto.Patient;
import com.practo.service.DoctorService;
import com.practo.service.PatientService;
import com.practo.valid.DoctorValidator;
import com.practo.valid.PatientValidator;

@Controller
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;
	@Autowired
	private DoctorValidator doctorValidator;
	@Autowired
	private MailSender mailSender;
	
	@RequestMapping(value = "/prep_reg_formd.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("doctor", new Doctor());
		return "reg_formd";
	}
	
	@RequestMapping(value = "/regd.htm",method = RequestMethod.POST)
	public String regForm(Doctor doctor,ModelMap map) {
		doctorService.addDoctor(doctor);
		return "log_formd";
	}
	
	@RequestMapping(value = "/prep_log_formd.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("doctor", new Doctor());
		return "log_formd";
	}
	
	@RequestMapping(value = "/logind.htm",method = RequestMethod.POST)
	public String login(Doctor doctor,BindingResult result,ModelMap map,HttpSession session) {
		
		doctorValidator.validate(doctor,result);
		if(result.hasErrors()) {
			return "log_formd";
		}
		
		boolean b = doctorService.findDoctor(doctor);
		if(b) {
			session.setAttribute("doctor", doctor);
			return "homed";
		}else {
			map.put("doctor", new Doctor());	
			return "log_formd";
		}
	}
	
	@RequestMapping(value = "/prep_profile_formd.htm",method = RequestMethod.GET)
	public String prepProfileForm(ModelMap map) {
		map.put("doctor", new Doctor());
		return "profile_formd";
	}
	
	@RequestMapping(value = "/prep_update_formd.htm",method = RequestMethod.GET)
	public String doctorUpdateForm(@RequestParam int doctorId,ModelMap map) {
		
		Doctor pat = doctorService.findDoctor(doctorId);
		map.put("doctor", pat);
		
		return "update_formd";
	}

	@RequestMapping(value = "/profile_update_formd.htm",method = RequestMethod.POST)
	public String doctorUpdate(Doctor doctor,ModelMap map,HttpSession session) {
		
		int doctorId = ((Doctor)session.getAttribute("doctor")).getDoctorId();
		doctor.setDoctorId(doctorId);
		
		doctorService.modifyDoctor(doctor);
		return "log_formd";
	}
	
	@RequestMapping(value = "/doctor_list_form.htm",method = RequestMethod.GET)
	public String doctorListForm(ModelMap map) {
		map.put("doctor", new Doctor());
		return "search_formp";
	}
	
	@RequestMapping(value = "/prep_doctor_list.htm",method = RequestMethod.POST)
	public String searchDoctor(Doctor doctor,ModelMap map,HttpSession session) {
	
		List<Doctor> li = doctorService.findDoctorList(doctor);
		map.put("dList", li);
		return "doctor_list"; 
	}
	
	@RequestMapping(value = "/confirm_bookin_form.htm",method = RequestMethod.GET)
	public String cfBookingForm(@RequestParam int doctorId,ModelMap map) {
		
		Doctor dr = doctorService.findDoctorId(doctorId);
		map.put("doctor", dr);
		
		return "confirm_booking";
	}
	

	@RequestMapping(value = "/prep_doctor_lista.htm",method = RequestMethod.GET)
	public String searchADoctor(Doctor doctor,ModelMap map,HttpSession session) {
	
		List<Doctor> li = doctorService.findAllDoctorList(doctor);
		map.put("dList", li);
		return "doctor_lista"; 
	
	}
	
	@RequestMapping(value = "/forgot_passwordd.htm",method = RequestMethod.POST)
	public String forgotDPassword(@RequestParam String doctorEmail,ModelMap map) {		
		String pass = doctorService.forgotPasswordD(doctorEmail);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("cdacmumbai3@gmail.com");  
	        message.setTo(doctorEmail);  
	        message.setSubject("Your password");  
	        message.setText(pass);     
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "index";
	}
	
	
	
	
	
	
	
	
	
	
	
}