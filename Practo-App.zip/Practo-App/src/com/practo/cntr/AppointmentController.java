package com.practo.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practo.dto.Appointment;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;
import com.practo.service.AppointmentService;

@Controller
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;
	
	@RequestMapping(value = "/insert_booking.htm",method = RequestMethod.POST)
	public String appointmentForm(Appointment appointment,ModelMap map) {
		appointmentService.addAppointment(appointment);
		return "homep";
	}
	
	


	@RequestMapping(value = "/prep_appo_list.htm",method = RequestMethod.GET)
	public String searchAppo(ModelMap map,HttpSession session) {
	
		int patientId = ((Patient)session.getAttribute("patient")).getPatientId();
		List<Patient> li = appointmentService.selectAll(patientId);
		map.put("aList", li);
		return "appo_list";
	}
	
	
	
	@RequestMapping(value = "/appo_delete.htm",method = RequestMethod.GET)
	public String appointmentDelete(@RequestParam int appointmentId,ModelMap map,HttpSession session) {
		
		appointmentService.removeAppointment(appointmentId); 
		
		int patientId = ((Patient)session.getAttribute("patient")).getPatientId();
		List<Patient> li = appointmentService.selectAll(patientId);
		map.put("aList", li);
		return "appo_list";
	}
	
	@RequestMapping(value = "/prep_appo_listd.htm",method = RequestMethod.GET)
	public String searchDocAppo(ModelMap map,HttpSession session) {
	
		int doctorId = ((Doctor)session.getAttribute("doctor")).getDoctorId();
		List<Doctor> li = appointmentService.selectDocAll(doctorId);
		map.put("aList", li);
		return "appo_listd";
	}
	
	@RequestMapping(value = "/appo_deleted.htm",method = RequestMethod.GET)
	public String appointmentDocDelete(@RequestParam int appointmentId,ModelMap map,HttpSession session) {
		
		appointmentService.removeAppointment(appointmentId); 
		
		int doctorId = ((Doctor)session.getAttribute("doctor")).getDoctorId();
		List<Doctor> li = appointmentService.selectDocAll(doctorId);
		map.put("aList", li);
		return "appo_listd";
	}
	
	@RequestMapping(value = "/prep_appo_lista.htm",method = RequestMethod.GET)
	public String searchAAppointment(Appointment appointment,ModelMap map,HttpSession session) {
	
		List<Appointment> li = appointmentService.findAllAppoList(appointment);
		map.put("aList", li);
		return "appo_lista"; 
	
	}
}
