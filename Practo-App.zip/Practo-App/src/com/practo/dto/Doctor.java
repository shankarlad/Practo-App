package com.practo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "doctor_data")
public class Doctor {
	@Id
	@GeneratedValue
	@Column(name = "doctor_id")
	private int doctorId;
	@Column(name = "doctor_name")
	private String doctorName;
	@Column(name = "doctor_email")
	private String doctorEmail;
	@Column(name = "doctor_mobile")
	private String doctorMobile;
	@Column(name = "doctor_dob")
	private String doctorDob;
	@Column(name = "doctor_gender")
	private String doctorGender;
	@Column(name="doctor_location")
	private String doctorLocation;
	@Column(name="doctor_speciality")
	private String doctorSpeciality;
	@Column (name="doctor_experience")
	private String doctorExperience;
	@Column(name = "doctor_password")
	private String doctorPassword;
	
	public Doctor() {
		
	}

	public Doctor(int doctorId) {
		super();
		this.doctorId = doctorId;
	}

	public Doctor(int doctorId, String doctorName, String doctorEmail, String doctorMobile, String doctorDob,
			String doctorGender, String doctorLocation, String doctorSpeciality, String doctorExperience,
			String doctorPassword) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorEmail = doctorEmail;
		this.doctorMobile = doctorMobile;
		this.doctorDob = doctorDob;
		this.doctorGender = doctorGender;
		this.doctorLocation = doctorLocation;
		this.doctorSpeciality = doctorSpeciality;
		this.doctorExperience = doctorExperience;
		this.doctorPassword = doctorPassword;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDoctorEmail() {
		return doctorEmail;
	}

	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}

	public String getDoctorMobile() {
		return doctorMobile;
	}

	public void setDoctorMobile(String doctorMobile) {
		this.doctorMobile = doctorMobile;
	}

	public String getDoctorDob() {
		return doctorDob;
	}

	public void setDoctorDob(String doctorDob) {
		this.doctorDob = doctorDob;
	}

	public String getDoctorGender() {
		return doctorGender;
	}

	public void setDoctorGender(String doctorGender) {
		this.doctorGender = doctorGender;
	}

	public String getDoctorLocation() {
		return doctorLocation;
	}

	public void setDoctorLocation(String doctorLocation) {
		this.doctorLocation = doctorLocation;
	}

	public String getDoctorSpeciality() {
		return doctorSpeciality;
	}

	public void setDoctorSpeciality(String doctorSpeciality) {
		this.doctorSpeciality = doctorSpeciality;
	}

	public String getDoctorExperience() {
		return doctorExperience;
	}

	public void setDoctorExperience(String doctorExperience) {
		this.doctorExperience = doctorExperience;
	}

	public String getDoctorPassword() {
		return doctorPassword;
	}

	public void setDoctorPassword(String doctorPassword) {
		this.doctorPassword = doctorPassword;
	}
	
	
	
}