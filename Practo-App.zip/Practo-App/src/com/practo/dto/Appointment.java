package com.practo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "appointment")
public class Appointment {
	@Id
	@GeneratedValue
	@Column(name = "appointment_id")
	private int appointmentId;
	@Column(name = "appointment_date")
	private String appointmentDate;
	@Column(name = "patient_Id")
	private String patientId;
	@Column(name = "patient_name")
	private String patientName;
	@Column(name = "doctor_name")
	private String doctorName;
	@Column(name = "doctor_id")
	private int doctorId;
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Appointment(int appointmentId) {
		super();
		this.appointmentId = appointmentId;
	}
	public Appointment(int appointmentId, String appointmentDate, String patientId, String patientName,
			String doctorName, int doctorId) {
		super();
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.patientId = patientId;
		this.patientName = patientName;
		this.doctorName = doctorName;
		this.doctorId = doctorId;
	}
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	
	
	
}
