package com.practo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_data")
public class Patient {
	@Id
	@GeneratedValue
	@Column(name = "patient_id")
	private int patientId;
	@Column(name = "patient_name")
	private String patientName;
	@Column(name = "patient_email")
	private String patientEmail;
	@Column(name = "patient_mobile")
	private String patientMobile;
	@Column(name = "patient_dob")
	private String patientDob;
	@Column(name = "patient_gender")
	private String patientGender;
	@Column(name = "patient_password")
	private String patientPassword;
	public Patient() {
		super();
		
	}
	public Patient(int patientId) {
		super();
		this.patientId = patientId;
	}
	public Patient(int patientId, String patientName, String patientEmail, String patientMobile, String patientDob,
			String patientGender, String patientPassword) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientEmail = patientEmail;
		this.patientMobile = patientMobile;
		this.patientDob = patientDob;
		this.patientGender = patientGender;
		this.patientPassword = patientPassword;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientEmail() {
		return patientEmail;
	}
	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}
	public String getPatientMobile() {
		return patientMobile;
	}
	public void setPatientMobile(String patientMobile) {
		this.patientMobile = patientMobile;
	}
	public String getPatientDob() {
		return patientDob;
	}
	public void setPatientDob(String patientDob) {
		this.patientDob = patientDob;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	public String getPatientPassword() {
		return patientPassword;
	}
	public void setPatientPassword(String patientPassword) {
		this.patientPassword = patientPassword;
	}
	
	
}
