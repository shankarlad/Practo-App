package com.practo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.practo.dao.DoctorDao;
import com.practo.dao.PatientDao;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Service
public class DoctorServiceImple implements DoctorService {
	
	@Autowired
	private DoctorDao doctorDao;
	@Override
	public void addDoctor(Doctor doctor) {
		doctorDao.insertDoctor(doctor);
		
	}
	
	@Override
	public boolean findDoctor(Doctor doctor) {
		return doctorDao.checkDoctor(doctor);
	}

	@Override
	public Doctor findDoctor(int doctorId) {
		return doctorDao.selectDoctor(doctorId);
	}

	@Override
	public void modifyDoctor(Doctor doctor) {
		doctorDao.updateDoctor(doctor);
		
		
	}

	@Override
	public List<Doctor> findDoctorList(Doctor doctor) {
		return doctorDao.searchDoctorList(doctor);
	}

	@Override
	public Doctor findDoctorId(int doctorId) {
		
		return doctorDao.searchDoctorId(doctorId);
	}

	@Override
	public List<Doctor> findAllDoctorList(Doctor doctor) {
		return doctorDao.searchAllDoctorList(doctor);
	}

	@Override
	public String forgotPasswordD(String doctorEmail) {
		
		return doctorDao.forgotPasswordD(doctorEmail);
	}

	

}