package com.practo.service;

import java.util.List;

import com.practo.dto.Appointment;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;

public interface AppointmentService {

	void addAppointment(Appointment appointment);

	List<Appointment> findAppoList(Appointment appointment);

	Appointment findAppointment(int appointmentId);

	List<Patient> selectAll(int patientId);

	void removeAppointment(int appointmentId);

	List<Doctor> selectDocAll(int doctorId);

	List<Appointment> findAllAppoList(Appointment appointment);



}
