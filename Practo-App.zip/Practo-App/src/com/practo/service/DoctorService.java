package com.practo.service;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.practo.dto.Doctor;

public interface DoctorService {
	void addDoctor(Doctor doctor);
	boolean findDoctor(Doctor doctor);
	Doctor findDoctor(int DoctorId);
	void modifyDoctor(Doctor doctor);
	List<Doctor> findDoctorList(Doctor doctor);
	Doctor findDoctorId(int doctorId);
	List<Doctor> findAllDoctorList(Doctor doctor);
	String forgotPasswordD(String doctorEmail);
}
