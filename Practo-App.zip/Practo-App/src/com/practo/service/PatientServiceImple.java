package com.practo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practo.dao.PatientDao;
import com.practo.dto.Patient;

@Service
public class PatientServiceImple implements PatientService {
	
	@Autowired
	private PatientDao patientDao;
	
	@Override
	public void addPatient(Patient patient) {
		patientDao.insertPatient(patient);
	}

	@Override
	public boolean findUser(Patient patient) {
		return patientDao.checkPatient(patient);
	}

	@Override
	public Patient findPatient(int patientId) {
		return patientDao.selectPatient(patientId);
	}

	@Override
	public void modifyPatient(Patient patient) {
		patientDao.updatePatient(patient);
		
	}

	@Override
	public List<Patient> findAllPatientList(Patient patient) {
		
		return patientDao.searchAllPatientList(patient);
	}

	@Override
	public String forgotPassword(String patientEmail) {
		
		return patientDao.forgotPassword(patientEmail);
	}



}
