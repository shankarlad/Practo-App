package com.practo.service;

import com.practo.dto.Admin;


public interface AdminService {
	void addAdmin(Admin admin);
	boolean findAdmin(Admin admin);
}
