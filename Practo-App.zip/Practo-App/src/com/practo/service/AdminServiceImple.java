package com.practo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practo.dao.AdminDao;
import com.practo.dto.Admin;


@Service
public class AdminServiceImple implements AdminService {
	
	@Autowired
	private AdminDao adminDao;
	
	@Override
	public void addAdmin(Admin admin) {
		adminDao.insertAdmin(admin);
		
	}

	@Override
	public boolean findAdmin(Admin admin) {
		
		return adminDao.checkAdmin(admin);
	}


	
	

}
