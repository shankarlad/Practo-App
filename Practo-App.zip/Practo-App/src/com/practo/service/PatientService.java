package com.practo.service;

import java.util.List;

import com.practo.dto.Patient;

public interface PatientService {
	void addPatient(Patient patient);
	boolean findUser(Patient patient);
	Patient findPatient(int patientId);
	void modifyPatient(Patient patient);
	List<Patient> findAllPatientList(Patient patient);
	String forgotPassword(String patientEmail);
}
