package com.practo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practo.dao.AppointmentDao;
import com.practo.dto.Appointment;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;



@Service
public class AppointmentServiceImple implements AppointmentService{

	@Autowired
	private AppointmentDao appointmentDao;

	@Override
	public void addAppointment(Appointment appointment) {
		appointmentDao.insertAppointment(appointment);
		
	}

	@Override
	public List<Appointment> findAppoList(Appointment appointment) {
		
			return appointmentDao.searchAppoList(appointment);
		
	}

	@Override
	public Appointment findAppointment(int appointmentId) {
		
		return appointmentDao.selectAppointment(appointmentId);
	}

	@Override
	public List<Patient> selectAll(int patientId) {
		
		return appointmentDao.selectAll(patientId);
	}

	@Override
	public void removeAppointment(int appointmentId) {
		appointmentDao.deleteAppointment(appointmentId);
		
	}

	@Override
	public List<Doctor> selectDocAll(int doctorId) {
		
		return appointmentDao.selectDocAll(doctorId);
	}

	@Override
	public List<Appointment> findAllAppoList(Appointment appointment) {
		
		return appointmentDao.searchAllAppoList(appointment);
	}

	

	
}
