package com.practo.dao;

import java.util.List;

import com.practo.dto.Patient;

public interface PatientDao {
	void insertPatient(Patient patient);
	boolean checkPatient(Patient patient);
	Patient selectPatient(int patientId);
	void updatePatient(Patient patient);
	List<Patient> searchAllPatientList(Patient patient);
	String forgotPassword(String patientEmail);
}
