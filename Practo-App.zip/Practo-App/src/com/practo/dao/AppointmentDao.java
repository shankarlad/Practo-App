package com.practo.dao;

import java.util.List;

import com.practo.dto.Appointment;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;

public interface AppointmentDao {

	void insertAppointment(Appointment appointment);

	List<Appointment> searchAppoList(Appointment appointment);

	Appointment selectAppointment(int appointmentId);

	List<Patient> selectAll(int patientId);

	void deleteAppointment(int appointmentId);

	List<Doctor> selectDocAll(int doctorId);

	List<Appointment> searchAllAppoList(Appointment appointment);


}
