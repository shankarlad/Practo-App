package com.practo.dao;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Repository
public class PatientDaoImple implements PatientDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertPatient(Patient patient) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(patient);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}

	@Override
	public boolean checkPatient(Patient patient) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>(){

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Patient where patientEmail = ? and patientPassword = ?");
				q.setString(0, patient.getPatientEmail());
				q.setString(1, patient.getPatientPassword());
				List<Patient> li = q.list();
				boolean flag = !li.isEmpty();
				patient.setPatientId(li.get(0).getPatientId());
				patient.setPatientName(li.get(0).getPatientName());
				patient.setPatientMobile(li.get(0).getPatientMobile());
				patient.setPatientDob(li.get(0).getPatientDob());
				patient.setPatientGender(li.get(0).getPatientGender());
				
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b;
	}

	@Override
	public Patient selectPatient(int patientId) {
		Patient patient = hibernateTemplate.execute(new HibernateCallback<Patient>() {

			@Override
			public Patient doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Patient pt = (Patient)session.get(Patient.class, patientId);
				tr.commit();
				session.flush();
				session.close();
				return pt;
			}
			
		});
		return patient;
	}

	@Override
	public void updatePatient(Patient patient) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(patient);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<Patient> searchAllPatientList(Patient patient) {
		List<Patient> dList = hibernateTemplate.execute(new HibernateCallback<List<Patient>>(){

			@Override
			public List<Patient> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Patient");
				List<Patient> li = q.list();		
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return dList;
		
	}

	@Override
	public String forgotPassword(String patientEmail) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Patient where patientEmail = ?");
				q.setString(0, patientEmail);
				List<Patient> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getPatientPassword();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;

		}
	
	
}
