package com.practo.dao;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.practo.dto.Doctor;

public interface DoctorDao {
	void insertDoctor(Doctor doctor);
	boolean checkDoctor(Doctor doctor);
	Doctor selectDoctor(int doctorId);
	void updateDoctor(Doctor doctor);
	List<Doctor> searchDoctorList(Doctor doctor);
	Doctor searchDoctorId(int doctorId);
	List<Doctor> searchAllDoctorList(Doctor doctor);
	String forgotPasswordD(String doctorEmail);
}