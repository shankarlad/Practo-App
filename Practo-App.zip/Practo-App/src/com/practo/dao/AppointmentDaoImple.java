package com.practo.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.practo.dto.Appointment;
import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Repository
public class AppointmentDaoImple implements AppointmentDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertAppointment(Appointment appointment) {
		
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(appointment);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}

			
			
		});
	}

	@Override
	public List<Appointment> searchAppoList(Appointment appointment) {
		List<Appointment> aList = hibernateTemplate.execute(new HibernateCallback<List<Appointment>>(){

			@Override
			public List<Appointment> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Appointment");
				List<Appointment> li = q.list();		
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return aList;
	}

	@Override
	public Appointment selectAppointment(int appointmentId) {
		Appointment appointment = hibernateTemplate.execute(new HibernateCallback<Appointment>() {

			@Override
			public Appointment doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Appointment ap = (Appointment)session.get(Appointment.class, appointmentId);
				tr.commit();
				session.flush();
				session.close();
				return ap;
			}
			
		});
		return appointment;
	}

	@Override
	public List<Patient> selectAll(int patientId) {
		List<Patient> aList = hibernateTemplate.execute(new HibernateCallback<List<Patient>>() {

			@Override
			public List<Patient> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Appointment where patientId = ?");
				q.setInteger(0, patientId);
				List<Patient> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return aList;
	}

	@Override
	public void deleteAppointment(int appointmentId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Appointment(appointmentId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<Doctor> selectDocAll(int doctorId) {
		List<Doctor> aList = hibernateTemplate.execute(new HibernateCallback<List<Doctor>>() {

			@Override
			public List<Doctor> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Appointment where doctorId = ?");
				q.setInteger(0, doctorId);
				List<Doctor> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return aList;
	}

	@Override
	public List<Appointment> searchAllAppoList(Appointment appointment) {
		List<Appointment> aList = hibernateTemplate.execute(new HibernateCallback<List<Appointment>>(){

			@Override
			public List<Appointment> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Appointment");
				List<Appointment> li = q.list();		
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return aList;
	}

	

}
