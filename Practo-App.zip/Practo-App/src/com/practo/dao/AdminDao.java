package com.practo.dao;

import com.practo.dto.Admin;

public interface AdminDao {

	void insertAdmin(Admin admin);

	boolean checkAdmin(Admin admin);
	
}
