package com.practo.dao;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.ui.ModelMap;

import com.practo.dto.Doctor;
import com.practo.dto.Patient;

@Repository
public class DoctorDaoImple implements DoctorDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertDoctor(Doctor doctor) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(doctor);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}
	
	@Override
	public boolean checkDoctor(Doctor doctor) {
		
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>(){

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor where doctorEmail = ? and doctorPassword = ?");
				q.setString(0, doctor.getDoctorEmail());
				q.setString(1, doctor.getDoctorPassword());
				List<Doctor> li = q.list();
				boolean flag = !li.isEmpty();
				doctor.setDoctorId(li.get(0).getDoctorId());
				doctor.setDoctorName(li.get(0).getDoctorName());
				doctor.setDoctorMobile(li.get(0).getDoctorMobile());
				doctor.setDoctorDob(li.get(0).getDoctorDob());
				doctor.setDoctorGender(li.get(0).getDoctorGender());
				doctor.setDoctorLocation(li.get(0).getDoctorLocation());
				doctor.setDoctorSpeciality(li.get(0).getDoctorSpeciality());
				doctor.setDoctorExperience(li.get(0).getDoctorExperience());
				
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b;
	}

	@Override
	public Doctor selectDoctor(int doctorId) {
		Doctor doctor = hibernateTemplate.execute(new HibernateCallback<Doctor>() {

			@Override
			public Doctor doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Doctor pt = (Doctor)session.get(Doctor.class, doctorId);
				tr.commit();
				session.flush();
				session.close();
				return pt;
			}
			
		});
		return doctor;
	}

	
	
	@Override
	public void updateDoctor(Doctor doctor) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(doctor);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}


	@Override
	public List<Doctor> searchDoctorList(Doctor doctor) {
		
		List<Doctor> dList = hibernateTemplate.execute(new HibernateCallback<List<Doctor>>(){

			@Override
			public List<Doctor> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor where doctorLocation = ? and doctorSpeciality = ?");
				q.setString(0, doctor.getDoctorLocation());
				q.setString(1, doctor.getDoctorSpeciality());
				List<Doctor> li = q.list();		
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return dList;
	}

	@Override
	public Doctor searchDoctorId(int doctorId) {
		Doctor doctor = hibernateTemplate.execute(new HibernateCallback<Doctor>() {

			@Override
			public Doctor doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Doctor dr = (Doctor)session.get(Doctor.class, doctorId);
				tr.commit();
				session.flush();
				session.close();
				return dr;
			}
			
		});
		return doctor;
	}

	
	@Override
	public List<Doctor> searchAllDoctorList(Doctor doctor) {
		List<Doctor> dList = hibernateTemplate.execute(new HibernateCallback<List<Doctor>>(){

			@Override
			public List<Doctor> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor");
				List<Doctor> li = q.list();		
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return dList;
	}

	
	
	
	@Override
	public String forgotPasswordD(String doctorEmail) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor where doctorEmail = ?");
				q.setString(0, doctorEmail);
				List<Doctor> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getDoctorPassword();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}
		
}